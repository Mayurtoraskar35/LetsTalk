package com.example.letstalk;

public class CountryData {
    public static final String[] countriesNames={"India","Pakistan"};
    public static final String[] countriesAreaCode={"91","92"};
}
