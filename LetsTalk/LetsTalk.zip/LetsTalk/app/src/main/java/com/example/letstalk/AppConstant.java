package com.example.letstalk;

public class AppConstant {
    public static final String PREFERENCE_FILE_NAME = "my_prefs";

    public static final String isLogin = "is_login";

    public static final String LOGGED_IN_USER_CONTACT_NUMBER = "logged_in_user_contact_number";

}
