package com.example.letstalk;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;

import java.util.List;

public class MyContactAdapter extends RecyclerView.Adapter<MyContactAdapter.MyViewHolder>{

    private static final String TAG = "MyContactAdapter";

    private List<User> mUserList;

    private Context mContext;

    public MyContactAdapter(Context context, List<User> userList){
        mUserList =userList;
        Log.d(TAG, "MyContactAdapter: "+mUserList);
        mContext = context;
        Log.d(TAG, "MyContactAdapter: "+mContext);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        Log.d(TAG, "onCreateViewHolder: ");
        View view = LayoutInflater.from(mContext).inflate(R.layout.contact_cardview, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int position) {
        //Log.d(TAG, "onBindViewHolder: ");
        User user = mUserList.get(position);

        String name = user.getUserName().toString().trim().substring(0,1).toUpperCase() + user.getUserName().toString().trim().substring(1).toLowerCase();

        //Log.d(TAG, "onBindViewHolder: name "+name);

        String surname = user.getUserSurname().toString().trim().substring(0,1).toUpperCase() + user.getUserSurname().toString().trim().substring(1).toLowerCase();

        //Log.d(TAG, "onBindViewHolder: surname "+surname);

        String fullName = name + " " + surname;

        //Log.d(TAG, "onBindViewHolder: fullame "+fullName);

        //Log.d(TAG, "onBindViewHolder: "+user.getUserName().trim().charAt(0));

        //Log.d(TAG, "onBindViewHolder: "+user.getUserMobile());

        String s =fullName.substring(0,1);

        //Log.d(TAG, "onBindViewHolder: s = "+s);

        myViewHolder.txtUserName.setText(fullName);
        myViewHolder.txtUserContact.setText(user.userMobile);

        ColorGenerator generator = ColorGenerator.DEFAULT;

        int color = generator.getRandomColor();



        TextDrawable drawable = TextDrawable.builder().buildRound(s, color);
        myViewHolder.image.setImageDrawable(drawable);

    }

    @Override
    public int getItemCount() {
        return mUserList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        TextView txtUserName;
        TextView txtUserContact;
        ImageView image;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            Log.d(TAG, "MyViewHolder: ");
            txtUserName = itemView.findViewById(R.id.username);
            txtUserContact = itemView.findViewById(R.id.contact_number);
            image = itemView.findViewById(R.id.user_image);
        }
    }
}
