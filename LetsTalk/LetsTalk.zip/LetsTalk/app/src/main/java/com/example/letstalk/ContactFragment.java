package com.example.letstalk;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the {@link ContactFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ContactFragment extends Fragment {

    MyContactAdapter adapter;

    Context context;

    DatabaseReference databaseUser;

    FirebaseDatabase firebaseDatabase;

    View view;

    RecyclerView recyclerView;

    User user;

    List<User> userList;

    private static final String TAG = "ContactFragment";

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ContactFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Log.d(TAG, "onCreateView: of ContaactFragment");

        //Log.d(TAG, "onCreateView: "+user);
        //Log.d(TAG, "onCreateView: "+userList);

        context = container.getContext();
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_contact, container, false);

        user = new User();

        recyclerView = view.findViewById(R.id.contact_recyclerview);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayout = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(linearLayout);

        DividerItemDecoration decoration = new DividerItemDecoration(context,DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(decoration);

        //Log.d(TAG, "onCreateView: " + databaseUser);

        //fetch Data From Database
        firebaseDatabase = FirebaseDatabase.getInstance();

        userList = new ArrayList<>();
        //Log.d(TAG, "onStart: " + user);
        //Log.d(TAG, "Database: "+databaseUser);

        Log.d(TAG, "onCreateView: " + databaseUser);

        Log.d(TAG, "onCreateView: "+firebaseDatabase);

        databaseUser = firebaseDatabase.getReference("users");

        Log.d(TAG, "onCreateView: " + databaseUser);

        Log.d(TAG, "onCreateView: 1236544 ");
        try {
            databaseUser.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Log.d(TAG, "onDataChange: "+dataSnapshot);
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        user = userSnapshot.getValue(User.class);
                        Log.d(TAG, "onDataChange: " + user);
                        userList.add(user);
                    }

                    adapter = new MyContactAdapter(context, userList);
                    Log.d(TAG, "after Send Adapter: " + adapter);
                    Log.d(TAG, "onCreateView: " + userList);
                    recyclerView.setAdapter(adapter);
                    Log.d(TAG, "onDataChange: ");
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.w(TAG, "Failed to read value.", databaseError.toException());
                }
            });
            Log.d(TAG, "onCreateView: ");
        }catch (Exception e){
            Log.d(TAG, "Exception: "+e.toString());
        }
        //MyContactAdapter adapter=new MyContactAdapter(context,userList);
        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

}
